import React, { useState } from "react";
import "./Testing.scss";

function Testing() {
  const questions = [
    {
      questionText: `In my living room I have _____ sofa, _____ two chairs, and _____ wall unit. Which of the following variants must be used in the blanks in the sentence above?`,
      answerOptions: [
        { answerText: "__,a,a", isCorrect: false },
        { answerText: "a, __, __", isCorrect: false },
        { answerText: "a,a,__", isCorrect: false },
        { answerText: "a,__,a", isCorrect: true },
      ],
    },
    {
      questionText:
        "Summer is hot, But winter is cold. Sugar is sweet, But lemon is _____.",
      answerOptions: [
        { answerText: "rich", isCorrect: false },
        { answerText: "yellow", isCorrect: false },
        { answerText: "sharp", isCorrect: false },
        { answerText: "sour", isCorrect: true },
      ],
    },
    {
      questionText:
        "Please, sit down and feel yourself _____, while I make some tea. Which of the following variants best fits the blank in the sentence above?",
      answerOptions: [
        { answerText: "at home", isCorrect: true },
        { answerText: "at school", isCorrect: false },
        { answerText: "in a park", isCorrect: false },
        { answerText: "in an office", isCorrect: false },
      ],
    },
    {
      questionText: "The slogan of a good student is",
      answerOptions: [
        {
          answerText: " The more you study, the better you learn.",
          isCorrect: true,
        },
        {
          answerText: "The less you study, the better you learn.",
          isCorrect: false,
        },
        {
          answerText: "The better you study, the worse you learn.",
          isCorrect: false,
        },
        {
          answerText: "The worse you study, the better you learn.",
          isCorrect: false,
        },
      ],
    },
    {
      questionText:
        "Many _____ come to Kyrgyzstan in summer. Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "visits", isCorrect: false },
        { answerText: "visit", isCorrect: false },
        { answerText: "visitors", isCorrect: true },
        { answerText: "visiting", isCorrect: false },
      ],
    },
    {
      questionText:
        "The girls were happy to be at their graduation party, _____ they realized how they would miss the school. Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "whoever", isCorrect: false },
        { answerText: "or", isCorrect: false },
        { answerText: "at the same time", isCorrect: false },
        { answerText: "because", isCorrect: true },
      ],
    },
    {
      questionText:
        "A: Are you doing anything tomorrow? B: No, nothing special.A: Shall we go to the football match then?B: No, I don’t really like football. Let’s go to the cinema. A: Brilliant idea. The speakers will most probably",
      answerOptions: [
        { answerText: "go to the football match", isCorrect: false },
        { answerText: "stay home", isCorrect: false },
        { answerText: "go to the movie", isCorrect: true },
        { answerText: "watch the football match at home", isCorrect: false },
      ],
    },
    {
      questionText:
        "Ostriches can’t fly, and _____ penguins. Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "neither can", isCorrect: true },
        { answerText: "neither can’t", isCorrect: false },
        { answerText: "so can", isCorrect: false },
        { answerText: "can’t", isCorrect: false },
      ],
    },
    {
      questionText:
        "Danger, do not enter, emergency, fire exit, first aid, harmful, no trespassing...Which of the following categories do the above given words belong to?",
      answerOptions: [
        { answerText: "Health words", isCorrect: false },
        { answerText: "Safety words", isCorrect: true },
        { answerText: "Family words", isCorrect: false },
        { answerText: "Calendar words", isCorrect: false },
      ],
    },
    {
      questionText:
        "– Jane? Where are you?– Hi, Mark. I am at the station. I _____ for the train.Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "wait", isCorrect: false },
        { answerText: "am waiting", isCorrect: true },
        { answerText: "have waited", isCorrect: false },
        { answerText: "waited", isCorrect: false },
      ],
    },
    {
      questionText:
        "– Yes, we live in the same building.Which of the following variants is the correct question to the answer above?",
      answerOptions: [
        { answerText: "Where does Emma live?", isCorrect: false },
        { answerText: "Do you know Emma?", isCorrect: true },
        { answerText: "Who lives in the same building?", isCorrect: false },
        {
          answerText: "Why does Emma live in this building?",
          isCorrect: false,
        },
      ],
    },
    {
      questionText:
        "The horse jumped over the fence and _____ away. Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "ran", isCorrect: true },
        { answerText: "was running", isCorrect: false },
        { answerText: "had run", isCorrect: false },
        { answerText: "had been running", isCorrect: false },
      ],
    },
    {
      questionText:
        "Which of the following variants must be used in the blanks in the sentence above? We _____ the boat to the dock so it wouldn’t go out when the ____ came in.",
      answerOptions: [
        { answerText: "tied, tide", isCorrect: true },
        { answerText: "tide, tide", isCorrect: false },
        { answerText: "tied, tied", isCorrect: false },
        { answerText: "tide, tied", isCorrect: false },
      ],
    },
    {
      questionText:
        "– I rang at one o’clock, but you were not at your office.– No, I _____ lunch.Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "had", isCorrect: false },
        { answerText: "am having", isCorrect: false },
        { answerText: "was having", isCorrect: true },
        { answerText: "have had", isCorrect: false },
      ],
    },
    {
      questionText:
        " A: Why didn’t you go to the movie with John?B: He _____ me to see the film that I _____ already.Which of the following variants must be used in the blanks in the sentence above?",
      answerOptions: [
        { answerText: "invites, / see", isCorrect: false },
        { answerText: "invited, / has seen", isCorrect: false },
        { answerText: "has invited, / see", isCorrect: false },
        { answerText: "invited, / had seen", isCorrect: true },
      ],
    },

    {
      questionText:
        "Nurdin: Ever since I met Asel, I haven’t been able to think about other girls. Askar: When I lived in Bishkek I loved Asel, but she didn’t love me.David: I admired Asel when I studied at the University, but we never dated. Misha: I lived in Bishkek for two years and I used to work with Asel.Which of the boys mentioned above is still in love with Asel?",
      answerOptions: [
        { answerText: "Nurdin", isCorrect: true },
        { answerText: "Askar", isCorrect: false },
        { answerText: "David", isCorrect: false },
        { answerText: "Misha", isCorrect: false },
      ],
    },

    {
      questionText:
        "A famous proverb says: “People have one life, but a cat has nine _____”.Which of the following variants must be used in the blank in the sentence above?",
      answerOptions: [
        { answerText: "life", isCorrect: false },
        { answerText: "lifes", isCorrect: false },
        { answerText: "live", isCorrect: false },
        { answerText: "lives", isCorrect: true },
      ],
    },
    {
      questionText:
        "The weather was _____ on the day of the graduation ball.Students respect _____ teachers.Which of the following variants must be used in both blanks in the sentences above?",
      answerOptions: [
        { answerText: "difficult", isCorrect: false },
        { answerText: "nasty", isCorrect: false },
        { answerText: "expensive", isCorrect: false },
        { answerText: "fair", isCorrect: true },
      ],
    },
    {
      questionText: `There was a great choice of cheese at the shop. _____ were offered twenty kinds of cheese to taste. Which of the following variants must be used in the blank in the sentence above?`,
      answerOptions: [
        { answerText: "Us", isCorrect: false },
        { answerText: "To us", isCorrect: false },
        { answerText: "We", isCorrect: true },
        { answerText: "For us", isCorrect: false },
      ],
    },
    {
      questionText: `A: You’ve been out in the garden working in the hot sun since early morning. You _____ be thirsty.`,
      answerOptions: [
        { answerText: "should", isCorrect: false },
        { answerText: "have to", isCorrect: false },
        { answerText: "ought to", isCorrect: false },
        { answerText: "must", isCorrect: true },
      ],
    },
  ];
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [score, setScore] = useState(0);

  const [value, setValue] = useState(true);

  const chengeValue = (event) => {
    setValue(event.target.value);
  };

  const handleAnswerOptionClick = (isCorrect) => {
    if (isCorrect) {
      setScore(score + 1);
    }
    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);

      console.log(score);
    } else {
      setShowScore(true);
    }
  };
  return (
    <div className="app">
      <div className="question-count">
        <span>Вопрос №{currentQuestion + 1}</span>
      </div>
      <div className="main">
        {showScore ? (
          <div className="score-section">
            You scored {score} out of {questions.length} English
          </div>
        ) : (
          <>
            <div className="question-section">
              <div className="question-text">
                {questions[currentQuestion].questionText}
              </div>
            </div>
            <div className="answer-section">
              <form className="form_radio">
                {questions[currentQuestion].answerOptions.map(
                  (answerOption) => (
                    <label>
                      <input
                        type="radio"
                        id={answerOption.answerID}
                        onClick={() =>
                          handleAnswerOptionClick(answerOption.isCorrect)
                        }
                      />
                      <span className="answer_text">
                        {answerOption.answerText}
                      </span>
                    </label>
                  )
                )}
              </form>
              <button className="buttonNext" onClick={handleAnswerOptionClick}>
                Следующий вопрос
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Testing;
