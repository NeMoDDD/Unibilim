{/* <div className="timetable_block">
        <div className="time">
          <p className="teach_txt">Расписание</p>
          <p className="date_txt">{name}</p>
        </div>
        <div className="date_table">
          <div className="cell">6 фев, пн</div>
          <div className="cell">7 фев, вт</div>
          <div className="cell">8 фев, ср</div>
          <div className="cell">9 фев, чт</div>
          <div className="cell">10 фев, пт</div>
          <div className="cell">11 фев, сб</div>
          <div className="cell" style={{ borderRight: "none" }}>
            12 фев, вс
          </div>
        </div>
        <div className="subj_table">
          <div className="col" style={{ marginLeft: "-5.5px",  }}>
            <div>
              <div
                className="subj_block"
                style={{ backgroundColor: "#CCFFFF" }}
              >
                <p className="subj_name">{arrSubjItem.Mon[1].subj}</p>
                <p className="subj_teach">{arrSubjItem.Mon[1].teach}</p>
                <p className="subj_time">{arrSubjItem.Mon[1].time}</p>
                <button className="subj_about">Подробнее</button>
              </div>
              <div
                className="subj_block"
                style={{ backgroundColor: "#FFF1A1" }}
              >
                <p className="subj_name">{arrSubjItem.Mon[2].subj}</p>
                <p className="subj_teach">{arrSubjItem.Mon[2].teach}</p>
                <p className="subj_time">{arrSubjItem.Mon[2].time}</p>
                <button className="subj_about2" style={{}}>
                  Подробнее
                </button>
              </div>
            </div>
          </div>
          <div className="col" style={{marginLeft:"-30px"}}></div>
          <div className="col"></div>
          <div className="col"></div>
          <div className="col"></div>
          <div className="col"></div>
        </div>
      </div> */}